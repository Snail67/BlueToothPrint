//
//  PrinterType.h
//  BLETR
//
//  Created by JQTEK on 15/3/30.
//  Copyright (c) 2015年 ISSC. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef BLETR_PrinterType_h
#define BLETR_PrinterType_h

typedef NS_ENUM(Byte,  ALIGN)
{
    LEFT,
    CENTER,
    RIGHT
};


#endif
