//
//  YDBluetoothConnectModel.m
//  PrintDemo
//
//  Created by long1009 on 16/2/1.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import "YDBluetoothConnectModel.h"

@implementation YDBluetoothConnectModel

@end
