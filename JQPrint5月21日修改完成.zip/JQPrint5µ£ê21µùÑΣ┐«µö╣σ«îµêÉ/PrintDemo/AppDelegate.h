//
//  AppDelegate.h
//  PrintDemo
//
//  Created by long1009 on 16/1/8.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

