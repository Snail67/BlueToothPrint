//
//  ViewController.m
//  PrintDemo
//
//  Created by long1009 on 16/1/8.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import "ViewController.h"
#import "YDPrintViewController.h"
#import "YDSettingController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithTitle:@"打印" style:UIBarButtonItemStyleDone target:self action:@selector(leftAction)];
    
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleDone target:self action:@selector(rightAction)];
    
    self.navigationItem.leftBarButtonItem = left;
    self.navigationItem.rightBarButtonItem = right;
}

- (void)leftAction{
    YDPrintViewController *PVC = [[YDPrintViewController alloc] init];
    [self.navigationController pushViewController:PVC animated:YES];
}

- (void)rightAction{
    YDSettingController *SVC = [[YDSettingController alloc] init];
    [self.navigationController pushViewController:SVC animated:YES];
}

@end
