//
//  DataTransparentViewController.m
//  BLEServerTest
//
//  Created by D500 user on 13/1/29.
//  Copyright (c) 2013年 D500 user. All rights reserved.
//

#import "YDPrintViewController.h"
#import "YDBlutoothTool.h"


#define BM77SPP_HW @"353035305f535050"
#define BM77SPP_FW @"32303233303230"
#define BM77SPP_AD 0xd97e

#define BLETR_HW @"353035305f424c455452"
#define BLETR_FW @"32303032303130"
#define BLETR_AD 0x4833



@interface YDPrintViewController ()

@end


@implementation YDPrintViewController


- (void)viewDidLoad
{
    
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 50);
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"打印" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(print) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    NSLog(@"%ld", [YDBlutoothTool sharedBlutoothTool].printType);
    
    
}

- (void)print
{
     NSLog(@"%ld", [YDBlutoothTool sharedBlutoothTool].printType);
    if ([YDBlutoothTool sharedBlutoothTool].printType == 1) {
        
        NSLog(@"peripheral =%@",[YDBlutoothTool sharedBlutoothTool].currentPeripheral);
        [[YDBlutoothTool sharedBlutoothTool] open:[YDBlutoothTool sharedBlutoothTool].currentPeripheral];
        [[YDBlutoothTool sharedBlutoothTool] flushRead];
        [self wrapPrintDatas];
        [self sendPrintData];
        [[YDBlutoothTool sharedBlutoothTool] reset];
        [[YDBlutoothTool sharedBlutoothTool] close];
        
    }else{
        [[YDBlutoothTool sharedBlutoothTool] printWithModel:nil];
    }
    
}

- (void)wrapPrintDatas{
    [[YDBlutoothTool sharedBlutoothTool] StartPage:576 pageHeight:720];
    [[YDBlutoothTool sharedBlutoothTool] zp_darwRect:4 top:2 right:568 bottom:688 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:10 * 8 endPointX:75*8-8 endPointY:10*8 width:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_darw1D_barcode:12*8 y:12*8 height:64 text:@"1234567890123"];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:19*8 y:21*8 text:@"1234567890123" font:55 fontsize:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:26 * 8 endPointX:75*8-8 endPointY:26*8 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:32*8 text:@"始发站：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8+64 y:32*8-8 text:@"齐齐哈尔" font:55 fontsize:3];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:42*8+48 text:@"目的站：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8-64 y:42*8+32 text:@"乌鲁木齐分拨" font:24 fontsize:3];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:58*8+40 text:@"票数：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8 y:58*8+40 text:@"8" font:55 fontsize:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:90*8-12*8 endPointX:75*8-8 endPointY:90*8-12*8 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:82*8 text:@"test123456" font:24 fontsize:1];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:28*8 y:82*8 text:@"2016-4-12" font:24 fontsize:1];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:28*8+20*8 y:82*8 text:@"16:20" font:24 fontsize:1];
    
    [[YDBlutoothTool sharedBlutoothTool] end];
    
}

-(void) sendPrintData{
    int r = [YDBlutoothTool sharedBlutoothTool].dataLength;
    
    NSData *data = [[YDBlutoothTool sharedBlutoothTool] getData:r];
    
    [[YDBlutoothTool sharedBlutoothTool] writeData:data];
}



@end
