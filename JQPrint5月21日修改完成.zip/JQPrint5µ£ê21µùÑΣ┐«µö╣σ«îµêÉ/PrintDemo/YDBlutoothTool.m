//
//  YDBlutoothTool.m
//  PrintDemo
//
//  Created by long1009 on 16/1/15.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import "YDBluetoothConnectModel.h"

#import "YDBlutoothTool.h"
#import "UUID.h"
#import "JQPrinter.h"

#import "MyLog.h"

#import <UIKit/UIKit.h>

#define ScanTimeInterval 1.0

// 新北洋状态定义
typedef enum
{
    YDPrinterOpen,
    YDPrinterPaperOut,
    YDPrinterDataLost
}YDPrinterState;

@interface YDBlutoothTool () <CBCentralManagerDelegate,CBPeripheralDelegate>
{
    NSInteger clickedRow;
}

@property (nonatomic, strong) CBCharacteristic *currentCharacteristic;


// 济强
@property (nonatomic,strong) CBCentralManager *centralManager;
@property (nonatomic,strong) CBPeripheral *selectedPeripheral;
@property (nonatomic,strong) NSTimer *scanTimer;
@property (nonatomic, strong) JQPrinter *printer;


//芝柯
@property (strong, nonatomic) CBCharacteristic* writeCharacteristic;
@property (strong, nonatomic) CBCharacteristic* readCharacteristic;


@property int connectState;

@end

@implementation YDBlutoothTool

static Byte receiveBuffer[1024];
static int receiveLength=0;
// 创建蓝牙单例
static YDBlutoothTool *blutoothTool;
+ (YDBlutoothTool *)sharedBlutoothTool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        blutoothTool = [[self alloc] init];
        [blutoothTool initWithCBCentralManager];
    });
    return blutoothTool;
}

// 初始化蓝牙管理者
- (void)initWithCBCentralManager
{
    if (!_centralManager)
    {
        dispatch_queue_t queue = dispatch_get_main_queue();
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:queue options:@{CBCentralManagerOptionShowPowerAlertKey:@YES}];
        [_centralManager setDelegate:self];
    }
}

// 开启蓝牙扫描
- (void)startScan
{
    NSLog(@"开始搜索");
    if (nil == _scanTimer)
    {
        _scanTimer = [NSTimer timerWithTimeInterval:ScanTimeInterval target:self selector:@selector(scanForPeripherals) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_scanTimer forMode:NSDefaultRunLoopMode];
    }
    if (_scanTimer && !_scanTimer.valid)
    {
        [_scanTimer fire];
    }
}

// 结束蓝牙扫描
- (void)stopScan
{
    NSLog(@"停止搜索");
    if (_scanTimer && _scanTimer.valid)
    {
        [_scanTimer invalidate];
        _scanTimer = nil;
    }
    [_centralManager stopScan];
}

// 断开蓝牙连接
- (void)breakConnect
{
    [_centralManager cancelPeripheralConnection:self.currentPeripheral];
    [self connectBreak];
}

// 搜索蓝牙设备
- (void)scanForPeripherals
{
    if (_centralManager.state == CBCentralManagerStateUnsupported)
    {
        //设备不支持蓝牙
        [self bluetoothConnectFailed];
    }
    else
    {
        //设备支持蓝牙连接
        if (_centralManager.state == CBCentralManagerStatePoweredOn)
        {
            //蓝牙开启状态
            [_centralManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:NO]}];
        }
    }
}

// 蓝牙连接失败
- (void)bluetoothConnectFailed
{
    //设备不支持蓝牙 弹框提示用户
    NSLog(@"不支持蓝牙");
}



#pragma mark - 蓝牙连接的代理方法
// 蓝牙连接状态
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBCentralManagerStatePoweredOff:
            NSLog(@"CBCentralManagerStatePoweredOff");
            break;
        case CBCentralManagerStatePoweredOn:
            NSLog(@"CBCentralManagerStatePoweredOn");
            break;
        case CBCentralManagerStateResetting:
            NSLog(@"CBCentralManagerStateResetting");
            break;
        case CBCentralManagerStateUnauthorized:
            NSLog(@"CBCentralManagerStateUnauthorized");
            break;
        case CBCentralManagerStateUnknown:
            NSLog(@"CBCentralManagerStateUnknown");
            break;
        case CBCentralManagerStateUnsupported:
            NSLog(@"CBCentralManagerStateUnsupported");
            break;
            
        default:
            break;
    }
}

// 发现蓝牙设备会进入该方法
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    NSLog(@"蓝牙名称%@",peripheral.name);
    
        if (0 == self.peripheralsArray.count)
        {
            peripheral.delegate = self;
            [self addPeripheralsArrayWith:peripheral];
        }
        else
        {
            BOOL isExist = NO;
            for (YDBluetoothConnectModel *bluetoothConnectModel in self.peripheralsArray){
                if ([bluetoothConnectModel.peripheral.name isEqualToString:peripheral.name]){
                    isExist = YES;
                 }
            }
            
            if (!isExist){
                peripheral.delegate = self;
                [self addPeripheralsArrayWith:peripheral];
            }
        }
        
        if (nil != self.blutoothToolContectedList){
            self.blutoothToolContectedList(self.peripheralsArray);
        }
}
- (void)addPeripheralsArrayWith:(CBPeripheral *)peripheral{
    YDBluetoothConnectModel *connectModel = [[YDBluetoothConnectModel alloc] init];
    connectModel.peripheral = peripheral;
    connectModel.bluetoothConnectType = YDBluetoothDisconnected;
    [self.peripheralsArray addObject:connectModel];
}

//连接蓝牙设备成功
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    NSLog(@"%@蓝牙已成功连接",peripheral.name);
    
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
    
    if ([peripheral.name isEqualToString:@"HDT334"]) {
        self.printType = 1;
        
    }else{
        self.printType = 2;
    }
    
    [self connectSuccee];
    
    NSMutableArray *uuids = [[NSMutableArray alloc] initWithObjects:[CBUUID UUIDWithString:UUIDSTR_DEVICE_INFO_SERVICE], [CBUUID UUIDWithString:UUIDSTR_ISSC_PROPRIETARY_SERVICE],[CBUUID UUIDWithString:UUIDSTR_DEVICE_HDT334],[CBUUID UUIDWithString:UUIDSTR_ISSC_ZICOXSERVICE], nil];
    [peripheral discoverServices:uuids];
}

//连接蓝牙设备失败
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"蓝牙连接失败");
    self.connectState=-1;
    [self connectFailed];
}

//断开连接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"已断开蓝牙连接");
    self.connectState=-1;
    [self connectBreak];
}

- (void)centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals{
    NSLog(@"11");
    if([peripherals count] >=1){
//        [self connectDevice:[peripherals objectAtIndex:0]];
    }
}

#pragma mark -蓝牙设备代理方法
// 外设已经查找到服务
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    // 遍历所有的服务
    for (CBService *service in peripheral.services){
        NSLog(@"==========%@", service.UUID.UUIDString);
            // 扫描服务下面的特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}

// 找到服务上得特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
   
    // 遍历所有的特征
    for(CBCharacteristic *characteristic in service.characteristics){
         NSLog(@"外围设备service:%@  特征值Characteristic:%@",service.UUID,characteristic.UUID);
        
        //济强打印机
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:@"49535343-8841-43F4-A8D4-ECBE34729BB3"]]){
            self.currentCharacteristic = characteristic;
            
        }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:@"49535343-1E4D-4BD9-BA61-23C647249616"]]){
            [peripheral setNotifyValue:TRUE forCharacteristic:characteristic];

        }
        
        //芝柯打印机
        else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:@"FFF2"]]){
            self.currentCharacteristic = characteristic;
            
            self.writeCharacteristic = characteristic;
            
            self.connectState=1;
        }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:@"FFF1"]]){
            self.readCharacteristic =characteristic;
            [peripheral setNotifyValue:TRUE forCharacteristic:characteristic];
            [self.currentPeripheral readValueForCharacteristic:characteristic];
        }

    }
}


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, characteristic);
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, service);
}


- (void)peripheral:(CBPeripheral *)peripheral didModifyServices:(NSArray<CBService *> *)invalidatedServices{
    NSLog(@"===%s===%@===", __func__, invalidatedServices);
}

- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, RSSI);
}
- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, characteristic);
}

//获取打印机返回值回调,数值存于characteristic value内  //获取外设发来的数据,不论是read和notify,获取数据都从这个方法中读取
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, characteristic);
     NSLog(@"[CBController] didUpdateValueForCharacteristic %@",[characteristic  value]);
    
    
    [peripheral readRSSI];
    if([characteristic.UUID isEqual:[CBUUID UUIDWithString:@"FFF1"]]){
        NSData* data = characteristic.value;
        if(data!=nil)
        {
            //NSLog(@"didUpdateValueForCharacteristic :%@",data);
            Byte *pData=[data bytes];
            for(int i=0;i<[data length];i++)
            {
                receiveBuffer[receiveLength++]=pData[i];
            }
        }
    }

    
    
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, descriptor);
}

#pragma mark-数据写入打印机didWriteValueForCharacteristic
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, characteristic);
   
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, descriptor);
}

- (void)peripheralDidUpdateName:(CBPeripheral *)peripheral{
    NSLog(@"===%s===%@===", __func__, peripheral);
}

- (void)peripheralDidUpdateRSSI:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"===%s===%@===", __func__, error);
}

#pragma mark - 打印机选择
// 获取已经配对好的设备信息
- (NSArray *)getConnectedEquipmentInfo
{
    NSMutableArray *uuids = [[NSMutableArray alloc] initWithObjects:[CBUUID UUIDWithString:UUIDSTR_DEVICE_INFO_SERVICE], [CBUUID UUIDWithString:UUIDSTR_ISSC_PROPRIETARY_SERVICE],[CBUUID UUIDWithString:UUIDSTR_DEVICE_HDT334], nil];
    return  [self.centralManager retrieveConnectedPeripheralsWithServices:uuids];
}

// 选择打印机
- (void)connectActionWithROW:(NSInteger)row{
    clickedRow = row;
    // 连接打印机断开之前蓝牙连接
    if (nil != self.currentPeripheral)
    {
        [self breakConnect];
    }
    
    // 检测蓝牙状态
    if (_centralManager.state == CBCentralManagerStateUnsupported)
    {
        //设备不支持蓝牙
        [self bluetoothConnectFailed];
    }
    else
    {
        //设备支持蓝牙连接
        if (_centralManager.state == CBCentralManagerStatePoweredOn)
        {
            //连接设备
            YDBluetoothConnectModel *connectModel = [self.peripheralsArray objectAtIndex:row];
            self.currentPeripheral = connectModel.peripheral;
            self.currentPeripheral.delegate = self;
            
            // 济强打印机连接方法
            [_centralManager connectPeripheral:self.currentPeripheral options:@{CBConnectPeripheralOptionNotifyOnConnectionKey:@YES,CBConnectPeripheralOptionNotifyOnNotificationKey:@YES,CBConnectPeripheralOptionNotifyOnDisconnectionKey:@YES}];
        }
        else{
            NSLog(@"您的蓝牙是关闭的");
        }
    }
}

#pragma mark - 蓝牙连接状态提示
- (void)connectSuccee{
    NSString *message = [NSString stringWithFormat:@"%@打印机连接成功", self.currentPeripheral.name];
    
//    if ([self.currentPeripheral.name isEqualToString:@"HDT334"]) {
//        self.printType = 1;
//        
//    }else{
//        self.printType = 2;
//    }
    [self alertViewShowWithMessage:message cancleButton:@"取消" certainButton:nil alertType:100];
    if (self.blutoothToolContectedSucceed !=nil)
    {
        for (YDBluetoothConnectModel *connectModel in self.peripheralsArray)
        {
            if ([connectModel.peripheral.name isEqualToString:self.currentPeripheral.name])
            {
                connectModel.bluetoothConnectType = YDBluetoothConnect;
            }
        }
        self.blutoothToolContectedSucceed(self.peripheralsArray);
    }
    // 连接打印机, 停止蓝牙搜索
    [self stopScan];
}

- (void)connectFailed
{
    NSString *message = [NSString stringWithFormat:@"%@打印机连接失败", self.currentPeripheral.name];
    
    [self alertViewShowWithMessage:message cancleButton:@"取消" certainButton:@"重新连接" alertType:101];
    if (nil != self.blutoothToolContectedFailed)
    {
        for (YDBluetoothConnectModel *connectModel in self.peripheralsArray)
        {
            connectModel.bluetoothConnectType = YDBluetoothDisconnected;
        }
        self.blutoothToolContectedFailed(self.peripheralsArray);
    }
}

- (void)connectBreak
{
     NSString *message = [NSString stringWithFormat:@"%@打印机已断开", self.currentPeripheral.name];
    [self alertViewShowWithMessage:message cancleButton:@"取消" certainButton:@"重新连接" alertType:102];
    if (nil != self.blutoothToolContectedUnlink)
    {
        for (YDBluetoothConnectModel *connectModel in self.peripheralsArray)
        {
            connectModel.bluetoothConnectType = YDBluetoothDisconnected;
        }
        self.blutoothToolContectedUnlink(self.peripheralsArray);
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        [self connectActionWithROW:clickedRow];
    }
}

- (void)alertViewShowWithMessage:(NSString *)message cancleButton:(NSString *)cancelButton certainButton:(NSString *)certainButton alertType:(NSInteger)alertType
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:self cancelButtonTitle:cancelButton otherButtonTitles:certainButton, nil];
    alertView.tag = alertType;
    
    [alertView show];
}

#pragma mark - 懒加载
- (NSMutableArray *)peripheralsArray
{
    if (nil == _peripheralsArray)
    {
        _peripheralsArray = [NSMutableArray array];
    }
    return _peripheralsArray;
}


// 打印开始事件响应
- (void)printWithModel:(YDPrintModel *)model
{
    self.printer.sendFinish = false;
    if(self.printer.sendFinish == TRUE){
        return;
    }
    
    self.printer.sendFlag = TRUE;
    [self wrapPrintDataWithModel:model];
    if (self.printer.printerInfo.wrap.dataLength){
        self.printer.sendFinish = TRUE;
    }
    [self sendPrintData];
    
}

- (NSMutableData *)hexStrToData:(NSString *)hexStr
{
    NSMutableData *data= [[NSMutableData alloc] init];
    NSUInteger len = [hexStr length];
    
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < len/2; i++)
    {
        byte_chars[0] = [hexStr characterAtIndex:i*2];
        byte_chars[1] = [hexStr characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [data appendBytes:&whole_byte length:1];
    }
    return data;
}

- (void)configureTransparentServiceUUID: (NSString *)serviceUUID txUUID:(NSString *)txUUID rxUUID:(NSString *)rxUUID{
    NSLog(@"8");
}

- (void)configureDeviceInformationServiceUUID:(NSString *)UUID1 UUID2:(NSString *)UUID2{
    NSLog(@"9");
}


//封装需要打印的数据到缓冲区
- (void)wrapPrintDataWithModel:(YDPrintModel *)model;
{
    //缓冲区复位
    [self.printer.printerInfo.wrap reset];
    [self.printer.esc restorePrinter];
    
    [self JQprintGetStatue];
    [self JQprintWithModel:model];
    
}

//发送打印数据
- (void)sendPrintData
{
    if (!self.printer.sendFlag)
    {
        return;
    }
   
    int r = self.printer.printerInfo.wrap.dataLength;
    if (r==0)
    {
        self.printer.sendFlag = FALSE;
        self.printer.sendFinish = FALSE;
        return;
    }
    //    int sendLength = printer.port.transmit.transmitSize;
    int sendLength = 50;
    if (r < sendLength)
    {
        sendLength = r;
    }
    NSData *data = [self.printer.printerInfo.wrap getData:sendLength];
    
    [self sendTransparentDataA:data];
}

// 打印
- (void)sendTransparentDataA:(NSData *)data
{
    [self.currentPeripheral writeValue:data forCharacteristic:self.currentCharacteristic type:CBCharacteristicWriteWithResponse];
    [NSTimer scheduledTimerWithTimeInterval:0.00001 target:self selector:@selector(sendPrintData) userInfo:nil repeats:NO];
}

//获取打印机状态
- (BOOL)JQprintGetStatue
{
    
     [self.printer.esc getPrinterStatue];
     return true;
}

// 济强打印机打印方法
- (BOOL)JQprintWithModel:(id)model{
//    [self.printer.jpl gotoGPL];
    
//    [self.printer.esc getPrinterStatue];
    if (![self.printer.jpl.page start:0 originY:0 pageWidth:576 pageHeight:730 rotate:x0]){
        return NO;
    }

#pragma mark -条形码打印的起始线
    [self.printer.jpl.grahic line:6 startPointY:80 endPointX:576 endPointY:80 width:2];
    [self.printer.jpl.grahic line:6 startPointY:215 endPointX:576 endPointY:215 width:2];
    [self.printer.jpl.grahic line:2 startPointY:610 endPointX:578 endPointY:610 width:2];
    
#pragma mark - 这是条形码打印
    NSString *barStr1 = @"12345678912";
    if (![self.printer.jpl.barcode code128:150 y:90 bar_height:70 unit_width:JPL_x3 rotate:ANGLE_0 text:barStr1]){
        return NO;
    }
    if (![self.printer.jpl.text drawOut:160 y:165 text:barStr1 fontHeight:40 bold:YES reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]){
        return NO;
    }
    
    //始发站:
    if (![self.printer.jpl.text drawOut:20 y:245 text:@"始发站:" fontHeight:35 bold:NO reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    if (![self.printer.jpl.text drawOut:150 y:235  text:@"萧山分拨中心" fontHeight:40 bold:YES reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    
    //目的站:
    if (![self.printer.jpl.text drawOut:20 y:380 text:@"目的站:" fontHeight:35 bold:NO reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    if (![self.printer.jpl.text drawOut:150 y:370  text:@"上海二级分拨" fontHeight:55 bold:YES reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    
    //票数:
    if (![self.printer.jpl.text drawOut:20 y:550 text:@"票数:" fontHeight:35 bold:NO reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    if (![self.printer.jpl.text drawOut:150 y:540 text:@"100" fontHeight:40 bold:YES reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]) {
        return NO;
    }
    
    //打印时间和打印人
    if (![self.printer.jpl.text drawOut:25 y:635 text:@"孙叔康" fontHeight:26 bold:NO reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]){
        return NO;
    }
    
    if (![self.printer.jpl.text drawOut:150 y:635 text:@"2016-05-18 17:18:24" fontHeight:26 bold:NO reverse:NO underLine:NO deletLine:NO enlargeX:x1 enlargeY:x1 rotateAngle:ROTATE_0]){
        return NO;
    }
    
    if (![self.printer.jpl.page end])
    {
        return NO;
    }
    if (![self.printer.jpl.page print]) {
        return NO;
    }
    
//    [self.printer.jpl feedNextLabelBegin];
    return YES;
}


- (JQPrinter *)printer
{
    if (nil == _printer)
    {
        _printer = [[JQPrinter alloc] init];
    }
    return _printer;
}


#pragma -mark芝柯打印机调试
- (void)waitUI:(int)ms
{
    CFRunLoopRef currentLoop = CFRunLoopGetCurrent();
    double delayInSeconds = ms/1000.0f;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds* NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        CFRunLoopStop(currentLoop);
    });
    CFRunLoopRun();
}


- (bool)open:(CBPeripheral *)peripheral {
    [self.centralManager stopScan];
    
    self.currentPeripheral=peripheral;
    self.connectState=0;
    [self.centralManager connectPeripheral: self.currentPeripheral  options:nil];
    while(self.connectState==0)
    {
        [self waitUI:50];
    }
    
    if(self.connectState!=1)return false;
    receiveLength=0;
    return true;
}

- (void)close{
    [self.centralManager cancelPeripheralConnection:self.currentPeripheral];
}

- (bool)write:(NSString*)strData
{
    NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *data=[strData dataUsingEncoding: gbkEncoding];
    
    int sended=0;
    while(sended<data.length)
    {
        int len=(int)data.length-sended;
        if(len>20)len=20;
        NSData *d = [data subdataWithRange:NSMakeRange(sended, len)];
        [self.currentPeripheral writeValue:d forCharacteristic:_writeCharacteristic type:CBCharacteristicWriteWithResponse];
        sended+=len;
    }
    return true;
}

- (bool)writeData:(NSData*)data{
    int sended=0;
    while(sended<data.length)
    {
        int len=(int)data.length-sended;
        if(len>20)len=20;
        NSData *d = [data subdataWithRange:NSMakeRange(sended, len)];
        [self.currentPeripheral writeValue:d forCharacteristic:_writeCharacteristic type:CBCharacteristicWriteWithResponse];
        sended+=len;
    }
    return true;
}

- (void)flushRead{
    receiveLength=0;
}

- (bool)readBytes:(BytePtr)data len:(int)len timeout:(int)timeout{
    for(int i=0;i<timeout/10;i++)
    {
        if(receiveLength>=len)break;
        
        [self waitUI:10];
    }
    if(receiveLength<len)return false;
    for(int i=0;i<len;i++)
    {
        data[i]=receiveBuffer[i];
    }
    for(int i=len;i<receiveLength;i++)
    {
        receiveBuffer[i-len]=receiveBuffer[i];
    }
    receiveLength-=len;
    return true;
}
/*
 * 绘制打印页面
 */
-(void)StartPage:(int) pageWidth  pageHeight:(int)pageHeight
{
    NSString *stringInt = [NSString stringWithFormat:@"%d",pageHeight];
    NSString *pageWidths = [NSString stringWithFormat:@"%d",pageWidth];
    
    [self addC:@"! 0 200 200 "];
    [self  addC:stringInt];
    [self addC:@" "];
    [self addC:@"1\n\r"];
    [self addC:@"PAGE-WIDTH "];
    [self addC:pageWidths];
    [self addC:@"\n\r"];
    [self addC:@"GAP-SENSE\n\r"];/////
}

/*
 * 绘制打印页面结束
 */
-(void)end{
    [  self addC:@"FORM\n\rPRINT\n"];
}

/*
 * 绘制text  x y为坐标，
 text为内容；
 font为字体，有24点阵和16点阵，24点阵填24，16点阵填55；
 fontsize 放大的倍数，填1表示 1乘以字体大小（等于没变大），所以想变大至少乘以2.
 */

-(void)zp_drawText:(int)x y:(int)y text:(NSString*)text font:(int)font fontsize:(int)fontsize;
{
    NSString *xx = [NSString stringWithFormat:@"%d",x];
    NSString *yy = [NSString stringWithFormat:@"%d",y];
    NSString *_font = [NSString stringWithFormat:@"%d",font];
    NSString *_fontsize = [NSString stringWithFormat:@"%d",fontsize];
    
    
    [self addC:@"SETMAG "];
    [self addC:_fontsize];
    [self addC:@" "];
    [self addC:_fontsize];
    [self addC:@"\n\r"];
    
    [self addC:@"T "];
    [self addC:_font];
    [self addC:@" "];
    [self addC:@"0 "];
    [self addC:xx];
    [self addC:@" "];
    [self addC:yy];
    [self addC:@" "];
    [self addC:text];
    [self addC:@"\n\r"];
    
    [self addC:@"SETMAG "];
    [self addC:@"1 "];
    [self addC:@"1 "];
    [self addC:@"\n\r"];
}


-(void)zp_drawLine:(int)startPointX startPiontY:(int)startPointY endPointX:(int)endPointX endPointY:(int)endPointY width:(int)width
{
    NSString *strsx = [NSString stringWithFormat:@"%d",startPointX];
    NSString *strsy = [NSString stringWithFormat:@"%d",startPointY];
    NSString *strsex = [NSString stringWithFormat:@"%d",endPointX];
    NSString *strey = [NSString stringWithFormat:@"%d",endPointY];
    NSString *wi = [NSString stringWithFormat:@"%d",width];
    
    [self addC:@"LINE "];
    [self addC:strsx];
    [self addC:@" "];
    [self addC:strsy];
    [self addC:@" "];
    [self addC:strsex];
    [self addC:@" "];
    [self addC:strey];
    [self addC:@" "];
    [self addC:wi];
    [self addC:@"\n\r"];
}


/*
 *一维条码绘制
 */
-(void)zp_darw1D_barcode:(int)x y:(int)y  height:(int)height text:(NSString*)text
{
    
    NSString *xx = [NSString stringWithFormat:@"%d",x];
    NSString *yy = [NSString stringWithFormat:@"%d",y];
    NSString *heights = [NSString stringWithFormat:@"%d",height];
    NSString *CODE128 = [NSString stringWithFormat:@"%d",128];
    [self addC:@"B "];
    [self addC:CODE128];
    [self addC:@" "];
    [self addC:@"2 "];
    [self addC:@"1 "];
    [self addC:heights];
    [self addC:@" "];
    [self addC:xx];
    [self addC:@" "];
    [self addC:yy];
    [self addC:@" "];
    [self addC:text];
    [self addC:@"\n\r"];
    
}
/*
 * QRCode
 *
 */
-(void) zp_darwQRCode:(int)x y:(int)y unit_width:(int)unit_width  text:(NSString*)text
{
    NSString *xx = [NSString stringWithFormat:@"%d",x];
    NSString *yy = [NSString stringWithFormat:@"%d",y];
    
    NSString *unit_widthss = [NSString stringWithFormat:@"%d",unit_width];
    [self addC:@"B QR "];
    [self addC:xx];
    [self addC:@" "];
    [self addC:yy];
    [self addC:@" "];
    [self addC:@"M 2"];
    [self addC:@" U "];
    [self addC:unit_widthss];
    [self addC:@"\n\r"];
    [self addC:@"MA,"];
    [self addC:text];
    [self addC:@"\n\r"];
    [self addC:@"ENDQR\n\r"];
}


-(void)zp_darwRect:(int)left top:(int)top right:(int)right bottom:(int)bottom width:(int)width
{
    
    NSString *lefts = [NSString stringWithFormat:@"%d",left];
    NSString *tops = [NSString stringWithFormat:@"%d",top];
    NSString *rights = [NSString stringWithFormat:@"%d",right];
    NSString *bottoms = [NSString stringWithFormat:@"%d",bottom];
    NSString *widths = [NSString stringWithFormat:@"%d",width];
    [self addC:@"BOX "];
    [self addC:lefts];
    [self addC:@" "];
    [self addC:tops];
    [self addC:@" "];
    [self addC:rights];
    [self addC:@" "];
    [self addC:bottoms];
    [self addC:@" "];
    [self addC:widths];
    [self addC:@"\n\r"];
}


@synthesize dataLength;
-(id)init{
    self = [super init];
    _offset = 0;
    _sendedDataLength = 0;
    return self;
}

-(void)reset{
    _offset = 0;
    _sendedDataLength = 0;
}

-(int) getDataLength{
    return _offset;
}

-(BOOL) addData:(Byte *)data length:(int)length{
    if (_offset + length > MAX_DATA_SIZE)
        return FALSE;
    memcpy(_buffer + _offset, data, length);
    _offset += length;
    return TRUE;
}

-(BOOL) addByte:(Byte)byte{
    if (_offset + 1 > MAX_DATA_SIZE)
        return FALSE;
    _buffer[_offset++] = byte;
    return TRUE;
}

-(BOOL) addShort:(ushort)data{
    if (_offset + 2 > MAX_DATA_SIZE)
        return FALSE;
    _buffer[_offset++] = (Byte)data;
    _buffer[_offset++] = (Byte)(data>>8);
    return TRUE;
}

-(BOOL) add:(NSString *)text{
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData* gbk = [text dataUsingEncoding:enc];
    Byte* gbkBytes = (Byte*)[gbk bytes]  ;
    if(![self addData:gbkBytes length:(int)gbk.length])
        return FALSE;
    return [self addByte:0x00];
}

-(BOOL) addC:(NSString *)text{
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData* gbk = [text dataUsingEncoding:enc];
    Byte* gbkBytes = (Byte*)[gbk bytes]  ;
    if(![self addData:gbkBytes length:(int)gbk.length])
        return FALSE;
    return true;
}

-(NSData*) getData:(int)sendLength{
    NSData *data;
    data = [[NSData alloc]initWithBytes:_buffer+_sendedDataLength length:sendLength];
    _offset -= sendLength;
    _sendedDataLength +=sendLength;
    return data;
}

@end
