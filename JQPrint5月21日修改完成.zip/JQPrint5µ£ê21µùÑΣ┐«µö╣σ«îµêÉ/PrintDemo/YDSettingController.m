//
//  YDSettingController.m
//  PrintDemo
//
//  Created by long1009 on 16/1/19.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import "YDSettingController.h"
#import "YDBluetoothCell.h"
#import "YDBlutoothTool.h"
#import "YDBluetoothConnectModel.h"

#define KHeight [[UIScreen mainScreen] bounds].size.height
#define KWidth  [[UIScreen mainScreen] bounds].size.width

@interface YDSettingController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, weak) UITableView *tableView;
@property (nonatomic, strong) NSArray *sourceArray;

@end

@implementation YDSettingController

- (NSArray *)sourceArray
{
    
    return [[YDBlutoothTool sharedBlutoothTool] peripheralsArray];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[YDBlutoothTool sharedBlutoothTool] stopScan];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UITableView *tableView = [[UITableView alloc] init];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.frame = self.view.bounds;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    
    UIButton *startButton = [UIButton buttonWithType:UIButtonTypeCustom];
    startButton.frame = CGRectMake(20, KHeight - 100, 50, 50);
    startButton.backgroundColor = [UIColor redColor];
    [startButton setTitle:@"开始" forState:UIControlStateNormal];
    [startButton addTarget:self action:@selector(startAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:startButton];
    
    UIButton *endButton = [UIButton buttonWithType:UIButtonTypeSystem];
    endButton.frame = CGRectMake(100, KHeight - 100, 50, 50);
    endButton.backgroundColor = [UIColor greenColor];
    [endButton setTitle:@"结束" forState:UIControlStateNormal];
    [endButton addTarget:self action:@selector(endAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:endButton];
    
    UIButton *connectButton = [UIButton buttonWithType:UIButtonTypeSystem];
    connectButton.frame = CGRectMake(100, KHeight - 100, 50, 50);
    connectButton.backgroundColor = [UIColor greenColor];
    [connectButton setTitle:@"结束" forState:UIControlStateNormal];
    [connectButton addTarget:self action:@selector(connectAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:connectButton];
    
    
}

- (void)startAction{
    YDBlutoothTool *blutooth = [YDBlutoothTool sharedBlutoothTool];
    blutooth.blutoothToolContectedList = ^(NSArray *tempArray){
        self.sourceArray = tempArray;
        [self.tableView reloadData];
    };
    
    blutooth.blutoothToolContectedSucceed = ^ (NSArray *tempArray){
        NSLog(@"连接成功");
        self.sourceArray = tempArray;
        [self.tableView reloadData];
    };
    
    blutooth.blutoothToolContectedFailed = ^(NSArray *tempArray){
         NSLog(@"连接失败");
        [self.tableView reloadData];
    };
    
    blutooth.blutoothToolContectedUnlink = ^(NSArray *tempArray){
        NSLog(@"断开连接");
        [self.tableView reloadData];
    };
    
    [[YDBlutoothTool sharedBlutoothTool] startScan];
}

- (void)endAction
{
    [[YDBlutoothTool sharedBlutoothTool] stopScan];
}

- (void)connectAction
{
    [YDBlutoothTool sharedBlutoothTool] ;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.sourceArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YDBluetoothCell *cell = [YDBluetoothCell bluetoothCellWithTableView:tableView];
    
    YDBluetoothConnectModel *model = self.sourceArray[indexPath.row];
    cell.titilString = model.peripheral.name;
    if (model.bluetoothConnectType == YDBluetoothConnect)
    {
        cell.isConnected = YES;
    }
    else
    {
        cell.isConnected = NO;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [[YDBlutoothTool sharedBlutoothTool] connectActionWithROW:indexPath.row];
    
    NSLog(@"设备= %@",[YDBlutoothTool sharedBlutoothTool].currentPeripheral);
//    NSLog(@"选择的是哪个类型打印机 =%ld", [YDBlutoothTool sharedBlutoothTool].printType);
    
//    if ([YDBlutoothTool sharedBlutoothTool].printType == 1) {
//        [[YDBlutoothTool sharedBlutoothTool] open:[YDBlutoothTool sharedBlutoothTool].currentPeripheral];
//        [[YDBlutoothTool sharedBlutoothTool] flushRead];
//        [self wrapPrintDatas];
//        [self sendPrintData];
//        [[YDBlutoothTool sharedBlutoothTool] reset];
//        [[YDBlutoothTool sharedBlutoothTool] close];
//    }
}


- (void)wrapPrintDatas{
    [[YDBlutoothTool sharedBlutoothTool] StartPage:576 pageHeight:720];
    [[YDBlutoothTool sharedBlutoothTool] zp_darwRect:4 top:2 right:568 bottom:688 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:10 * 8 endPointX:75*8-8 endPointY:10*8 width:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_darw1D_barcode:12*8 y:12*8 height:64 text:@"1234567890123"];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:19*8 y:21*8 text:@"1234567890123" font:55 fontsize:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:26 * 8 endPointX:75*8-8 endPointY:26*8 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:32*8 text:@"始发站：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8+64 y:32*8-8 text:@"齐齐哈尔" font:55 fontsize:3];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:42*8+48 text:@"目的站：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8-64 y:42*8+32 text:@"乌鲁木齐分拨" font:24 fontsize:3];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:58*8+40 text:@"票数：" font:55 fontsize:2];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:24*8 y:58*8+40 text:@"8" font:55 fontsize:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawLine:4 startPiontY:90*8-12*8 endPointX:75*8-8 endPointY:90*8-12*8 width:2];
    
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:8 y:82*8 text:@"test123456" font:24 fontsize:1];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:28*8 y:82*8 text:@"2016-4-12" font:24 fontsize:1];
    [[YDBlutoothTool sharedBlutoothTool] zp_drawText:28*8+20*8 y:82*8 text:@"16:20" font:24 fontsize:1];
    
    [[YDBlutoothTool sharedBlutoothTool] end];
    
}

-(void) sendPrintData{
    
    int r = [YDBlutoothTool sharedBlutoothTool].dataLength;
    
    NSData *data = [[YDBlutoothTool sharedBlutoothTool] getData:r];
    
    [[YDBlutoothTool sharedBlutoothTool] writeData:data];
    
}



@end
