//
//  YDBlutoothTool.h
//  PrintDemo
//
//  Created by long1009 on 16/1/15.
//  Copyright © 2016年 long1009. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <UIKit/UIKit.h>
#define MAX_DATA_SIZE (1024)
@class YDPrintModel;
@class MyPeripheral;

typedef void (^YDBlutoothToolContectedList) (NSArray *);
typedef void (^YDBlutoothToolContectedSucceed) (NSArray *);
typedef void (^YDBlutoothToolContectedFailed) (NSArray *);
typedef void (^YDBlutoothToolContectedUnlink) (NSArray *);

@interface YDBlutoothTool : NSObject
{
    Byte _buffer[MAX_DATA_SIZE];
    int _offset;
    int _sendedDataLength;
    int leftDataLength;
    
}

@property (nonatomic,assign)NSInteger printType;

@property (getter=getDataLength,readonly)int dataLength;

// 蓝牙连接列表
@property (nonatomic, copy) YDBlutoothToolContectedList blutoothToolContectedList;

// 蓝牙连接成功
@property (nonatomic, copy) YDBlutoothToolContectedSucceed blutoothToolContectedSucceed;

// 蓝牙连接失败
@property (nonatomic, copy) YDBlutoothToolContectedFailed blutoothToolContectedFailed;

// 蓝牙断开连接
@property (nonatomic, copy) YDBlutoothToolContectedUnlink blutoothToolContectedUnlink;

// 蓝牙搜索结果数组
@property (nonatomic, strong) NSMutableArray *peripheralsArray;

// 当前设备
@property (nonatomic, strong) CBPeripheral *currentPeripheral;

// 蓝牙单例
+ (YDBlutoothTool *)sharedBlutoothTool;

@property (strong, nonatomic) CBPeripheral* peripheral;

// 开启蓝牙搜索
- (void)startScan;

// 结束蓝牙搜索
- (void)stopScan;

// 断开蓝牙连接
- (void)breakConnect;

// 连接蓝牙
- (void)connectActionWithROW:(NSInteger)row;

// 打印
- (void)printWithModel:(YDPrintModel *)model;

// 获取已经配对好的设备信息
- (NSArray *)getConnectedEquipmentInfo;


-(void)StartPage:(int) pageWidth  pageHeight:(int)pageHeight ;
-(void)end;
-(void)zp_drawText:(int)x y:(int)y text:(NSString*)text font:(int)fontsize fontsize:(int)fontsize;
-(void)zp_drawLine:(int)startPointX startPiontY:(int)startPointY endPointX:(int)endPointX endPointY:(int)endPointY width:(int)width;
-(void)zp_darw1D_barcode:(int)x y:(int)y  height:(int)height text:(NSString*)text;
-(void) zp_darwQRCode:(int)x y:(int)y unit_width:(int)unit_width  text:(NSString*)text;
-(void)zp_darwRect:(int)left top:(int)top right:(int)right bottom:(int)bottom width:(int)width;



-(NSData*) getData:(int)sendLength;
- (bool)writeData:(NSData*)data;
- (void)flushRead;
-(void) reset;

- (bool)open:(CBPeripheral *)peripheral ;
- (void)close;
@end
