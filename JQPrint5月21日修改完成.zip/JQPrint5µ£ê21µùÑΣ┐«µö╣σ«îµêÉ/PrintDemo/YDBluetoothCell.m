//
//  YDBluetoothCell.m
//  PrintDemo
//
//  Created by long1009 on 16/1/15.
//  Copyright © 2016年 long1009. All rights reserved.
//

#import "YDBluetoothCell.h"

@interface YDBluetoothCell ()

@property (weak, nonatomic) IBOutlet UILabel *titilLabel;

@property (weak, nonatomic) IBOutlet UILabel *stateLabel;


@end


@implementation YDBluetoothCell

+ (YDBluetoothCell *)bluetoothCellWithTableView:(UITableView *)tableView
{
    static NSString *cellIdentifier = @"bluetoothCell";
    YDBluetoothCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YDBluetoothCell" owner:nil options:nil] lastObject];
    }
    return cell;
}


- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)setTitilString:(NSString *)titilString
{
    _titilString = titilString;
    self.titilLabel.text = titilString;
}

- (void)setIsConnected:(BOOL)isConnected
{
    _isConnected = isConnected;
    if (YES == isConnected)
    {
        self.stateLabel.text = @"已连接";
    }
    else
    {
        self.stateLabel.text = nil;
    }
    
}



@end
